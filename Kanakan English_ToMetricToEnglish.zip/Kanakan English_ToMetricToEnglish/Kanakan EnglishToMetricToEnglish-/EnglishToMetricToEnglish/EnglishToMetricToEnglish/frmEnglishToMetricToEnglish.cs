﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnglishToMetricToEnglish
{
    public partial class frmEnglishToMetricToEnglish : Form
    {
        public frmEnglishToMetricToEnglish()
        {
            InitializeComponent();
        }
        private void EnglishToMetricToEnglishFrm_Load(object sender, EventArgs e)
        {

        }

        private void chkMiles_CheckedChanged(object sender, EventArgs e)
        {
            inputtingEnglish();
        }

        private void txtMiles_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void chkYards_CheckedChanged(object sender, EventArgs e)
        {
            inputtingEnglish();
        }

        private void txtYards_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkFeet_CheckedChanged(object sender, EventArgs e)
        {
            inputtingEnglish();
        }

        private void txtFeet_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void chkInches_CheckedChanged(object sender, EventArgs e)
        {
            inputtingEnglish();
        }

        private void txtInches_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkKilometers_CheckedChanged(object sender, EventArgs e)
        {
            inputtingMetric();
        }
        private void txtKilometers_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkMeters_CheckedChanged(object sender, EventArgs e)
        {
            inputtingMetric();
        }

        private void txtMeters_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkCentimeters_CheckedChanged(object sender, EventArgs e)
        {
            inputtingMetric();
        }

        private void txtCentimeters_TextChanged(object sender, EventArgs e)
        {

        }

        private void inputtingMetric()
        {
            if (chkKilometers.Checked || chkMeters.Checked || chkCentimeters.Checked
                ||optMetricToEnglish.Checked)
            {

                grpEnglish.Enabled = false;
                clearMetric();
            }
            else
                grpEnglish.Enabled = true;
        }
        private void inputtingEnglish()
        {
            if (chkMiles.Checked || chkYards.Checked || chkFeet.Checked || chkInches.Checked
                || optEnglishToMetric.Checked)
            {

                grpMetric.Enabled = false;
                clearMetric();
            }
            else
                grpMetric.Enabled = true;
        }

       
        public void clearEnglish()
        {
            txtMiles.Text = "";
            txtYards.Text = "";
            txtFeet.Text = "";
            txtInches.Text = "";

        }
        public void clearMetric()
        {
            txtKilometers.Text = "";
            txtMeters.Text = "";
            txtCentimeters.Text = "";
        }

        private void optEnglishToMetric_CheckedChanged(object sender, EventArgs e)
        {
            inputtingEnglish();
            clearMetric();
        }

        private void optMetricToEnglish_CheckedChanged(object sender, EventArgs e)
        {
            inputtingMetric();
            clearEnglish();
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            clearEnglish();
            clearMetric();

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            //Convert
            if (chkMiles.Checked)
            {
                EnglishToMetric convertingANumber = new EnglishToMetric();
                convertingANumber.getKilometers();
                convertingANumber.getMeters();
                convertingANumber.getCentimeters();
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}
