﻿namespace EnglishToMetricToEnglish
{
    partial class frmEnglishToMetricToEnglish
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConvert = new System.Windows.Forms.Button();
            this.txtCentimeters = new System.Windows.Forms.TextBox();
            this.txtKilometers = new System.Windows.Forms.TextBox();
            this.txtMeters = new System.Windows.Forms.TextBox();
            this.optMetricToEnglish = new System.Windows.Forms.RadioButton();
            this.optEnglishToMetric = new System.Windows.Forms.RadioButton();
            this.grpMetric = new System.Windows.Forms.GroupBox();
            this.chkCentimeters = new System.Windows.Forms.CheckBox();
            this.chkMeters = new System.Windows.Forms.CheckBox();
            this.chkKilometers = new System.Windows.Forms.CheckBox();
            this.grpEnglish = new System.Windows.Forms.GroupBox();
            this.chkInches = new System.Windows.Forms.CheckBox();
            this.chkFeet = new System.Windows.Forms.CheckBox();
            this.chkYards = new System.Windows.Forms.CheckBox();
            this.chkMiles = new System.Windows.Forms.CheckBox();
            this.txtInches = new System.Windows.Forms.TextBox();
            this.txtFeet = new System.Windows.Forms.TextBox();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.grpChoseOne = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpMetric.SuspendLayout();
            this.grpEnglish.SuspendLayout();
            this.grpChoseOne.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(173, 71);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 8;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // txtCentimeters
            // 
            this.txtCentimeters.Location = new System.Drawing.Point(92, 86);
            this.txtCentimeters.Name = "txtCentimeters";
            this.txtCentimeters.Size = new System.Drawing.Size(100, 20);
            this.txtCentimeters.TabIndex = 17;
            this.txtCentimeters.TextChanged += new System.EventHandler(this.txtCentimeters_TextChanged);
            // 
            // txtKilometers
            // 
            this.txtKilometers.Location = new System.Drawing.Point(92, 34);
            this.txtKilometers.Name = "txtKilometers";
            this.txtKilometers.Size = new System.Drawing.Size(100, 20);
            this.txtKilometers.TabIndex = 18;
            this.txtKilometers.TextChanged += new System.EventHandler(this.txtKilometers_TextChanged);
            // 
            // txtMeters
            // 
            this.txtMeters.Location = new System.Drawing.Point(92, 60);
            this.txtMeters.Name = "txtMeters";
            this.txtMeters.Size = new System.Drawing.Size(100, 20);
            this.txtMeters.TabIndex = 19;
            this.txtMeters.TextChanged += new System.EventHandler(this.txtMeters_TextChanged);
            // 
            // optMetricToEnglish
            // 
            this.optMetricToEnglish.AutoSize = true;
            this.optMetricToEnglish.Location = new System.Drawing.Point(141, 32);
            this.optMetricToEnglish.Name = "optMetricToEnglish";
            this.optMetricToEnglish.Size = new System.Drawing.Size(101, 17);
            this.optMetricToEnglish.TabIndex = 21;
            this.optMetricToEnglish.TabStop = true;
            this.optMetricToEnglish.Text = "MetricToEnglish";
            this.optMetricToEnglish.UseVisualStyleBackColor = true;
            this.optMetricToEnglish.CheckedChanged += new System.EventHandler(this.optMetricToEnglish_CheckedChanged);
            // 
            // optEnglishToMetric
            // 
            this.optEnglishToMetric.AutoSize = true;
            this.optEnglishToMetric.Location = new System.Drawing.Point(15, 35);
            this.optEnglishToMetric.Name = "optEnglishToMetric";
            this.optEnglishToMetric.Size = new System.Drawing.Size(101, 17);
            this.optEnglishToMetric.TabIndex = 22;
            this.optEnglishToMetric.TabStop = true;
            this.optEnglishToMetric.Text = "EnglishToMetric";
            this.optEnglishToMetric.UseVisualStyleBackColor = true;
            this.optEnglishToMetric.CheckedChanged += new System.EventHandler(this.optEnglishToMetric_CheckedChanged);
            // 
            // grpMetric
            // 
            this.grpMetric.Controls.Add(this.chkCentimeters);
            this.grpMetric.Controls.Add(this.chkMeters);
            this.grpMetric.Controls.Add(this.chkKilometers);
            this.grpMetric.Controls.Add(this.txtMeters);
            this.grpMetric.Controls.Add(this.txtCentimeters);
            this.grpMetric.Controls.Add(this.txtKilometers);
            this.grpMetric.Location = new System.Drawing.Point(219, 126);
            this.grpMetric.Margin = new System.Windows.Forms.Padding(2);
            this.grpMetric.Name = "grpMetric";
            this.grpMetric.Padding = new System.Windows.Forms.Padding(2);
            this.grpMetric.Size = new System.Drawing.Size(198, 141);
            this.grpMetric.TabIndex = 23;
            this.grpMetric.TabStop = false;
            this.grpMetric.Text = "metric";
            // 
            // chkCentimeters
            // 
            this.chkCentimeters.AutoSize = true;
            this.chkCentimeters.Location = new System.Drawing.Point(5, 88);
            this.chkCentimeters.Name = "chkCentimeters";
            this.chkCentimeters.Size = new System.Drawing.Size(81, 17);
            this.chkCentimeters.TabIndex = 22;
            this.chkCentimeters.Text = "Centimeters";
            this.chkCentimeters.UseVisualStyleBackColor = true;
            this.chkCentimeters.CheckedChanged += new System.EventHandler(this.chkCentimeters_CheckedChanged);
            // 
            // chkMeters
            // 
            this.chkMeters.AutoSize = true;
            this.chkMeters.Location = new System.Drawing.Point(5, 64);
            this.chkMeters.Name = "chkMeters";
            this.chkMeters.Size = new System.Drawing.Size(58, 17);
            this.chkMeters.TabIndex = 21;
            this.chkMeters.Text = "Meters";
            this.chkMeters.UseVisualStyleBackColor = true;
            this.chkMeters.CheckedChanged += new System.EventHandler(this.chkMeters_CheckedChanged);
            // 
            // chkKilometers
            // 
            this.chkKilometers.AutoSize = true;
            this.chkKilometers.Location = new System.Drawing.Point(5, 35);
            this.chkKilometers.Margin = new System.Windows.Forms.Padding(2);
            this.chkKilometers.Name = "chkKilometers";
            this.chkKilometers.Size = new System.Drawing.Size(74, 17);
            this.chkKilometers.TabIndex = 20;
            this.chkKilometers.Text = "Kilometers";
            this.chkKilometers.UseVisualStyleBackColor = true;
            this.chkKilometers.CheckedChanged += new System.EventHandler(this.chkKilometers_CheckedChanged);
            // 
            // grpEnglish
            // 
            this.grpEnglish.Controls.Add(this.chkInches);
            this.grpEnglish.Controls.Add(this.chkFeet);
            this.grpEnglish.Controls.Add(this.chkYards);
            this.grpEnglish.Controls.Add(this.chkMiles);
            this.grpEnglish.Controls.Add(this.txtInches);
            this.grpEnglish.Controls.Add(this.txtFeet);
            this.grpEnglish.Controls.Add(this.txtMiles);
            this.grpEnglish.Controls.Add(this.txtYards);
            this.grpEnglish.Location = new System.Drawing.Point(7, 126);
            this.grpEnglish.Margin = new System.Windows.Forms.Padding(2);
            this.grpEnglish.Name = "grpEnglish";
            this.grpEnglish.Padding = new System.Windows.Forms.Padding(2);
            this.grpEnglish.Size = new System.Drawing.Size(198, 141);
            this.grpEnglish.TabIndex = 24;
            this.grpEnglish.TabStop = false;
            this.grpEnglish.Text = "english";
            // 
            // chkInches
            // 
            this.chkInches.AutoSize = true;
            this.chkInches.Location = new System.Drawing.Point(5, 110);
            this.chkInches.Name = "chkInches";
            this.chkInches.Size = new System.Drawing.Size(58, 17);
            this.chkInches.TabIndex = 32;
            this.chkInches.Text = "Inches";
            this.chkInches.UseVisualStyleBackColor = true;
            this.chkInches.CheckedChanged += new System.EventHandler(this.chkInches_CheckedChanged);
            // 
            // chkFeet
            // 
            this.chkFeet.AutoSize = true;
            this.chkFeet.Location = new System.Drawing.Point(5, 88);
            this.chkFeet.Name = "chkFeet";
            this.chkFeet.Size = new System.Drawing.Size(47, 17);
            this.chkFeet.TabIndex = 31;
            this.chkFeet.Text = "Feet";
            this.chkFeet.UseVisualStyleBackColor = true;
            this.chkFeet.CheckedChanged += new System.EventHandler(this.chkFeet_CheckedChanged);
            // 
            // chkYards
            // 
            this.chkYards.AutoSize = true;
            this.chkYards.Location = new System.Drawing.Point(5, 64);
            this.chkYards.Name = "chkYards";
            this.chkYards.Size = new System.Drawing.Size(53, 17);
            this.chkYards.TabIndex = 30;
            this.chkYards.Text = "Yards";
            this.chkYards.UseVisualStyleBackColor = true;
         
            // 
            // chkMiles
            // 
            this.chkMiles.AutoSize = true;
            this.chkMiles.Location = new System.Drawing.Point(5, 38);
            this.chkMiles.Name = "chkMiles";
            this.chkMiles.Size = new System.Drawing.Size(50, 17);
            this.chkMiles.TabIndex = 26;
            this.chkMiles.Text = "Miles";
            this.chkMiles.UseVisualStyleBackColor = true;
            this.chkMiles.CheckedChanged += new System.EventHandler(this.chkMiles_CheckedChanged);
            // 
            // txtInches
            // 
            this.txtInches.Location = new System.Drawing.Point(77, 110);
            this.txtInches.Name = "txtInches";
            this.txtInches.Size = new System.Drawing.Size(100, 20);
            this.txtInches.TabIndex = 29;
            this.txtInches.TextChanged += new System.EventHandler(this.txtInches_TextChanged);
            // 
            // txtFeet
            // 
            this.txtFeet.Location = new System.Drawing.Point(77, 84);
            this.txtFeet.Name = "txtFeet";
            this.txtFeet.Size = new System.Drawing.Size(100, 20);
            this.txtFeet.TabIndex = 28;
            this.txtFeet.TextChanged += new System.EventHandler(this.txtFeet_TextChanged);
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(77, 35);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 20);
            this.txtMiles.TabIndex = 26;
            this.txtMiles.TextChanged += new System.EventHandler(this.txtMiles_TextChanged);
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(77, 61);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(100, 20);
            this.txtYards.TabIndex = 25;
            // 
            // grpChoseOne
            // 
            this.grpChoseOne.Controls.Add(this.optMetricToEnglish);
            this.grpChoseOne.Controls.Add(this.optEnglishToMetric);
            this.grpChoseOne.Location = new System.Drawing.Point(84, 9);
            this.grpChoseOne.Margin = new System.Windows.Forms.Padding(2);
            this.grpChoseOne.Name = "grpChoseOne";
            this.grpChoseOne.Padding = new System.Windows.Forms.Padding(2);
            this.grpChoseOne.Size = new System.Drawing.Size(248, 57);
            this.grpChoseOne.TabIndex = 25;
            this.grpChoseOne.TabStop = false;
            this.grpChoseOne.Text = "chose one";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(84, 71);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 26;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(257, 71);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 27;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmEnglishToMetricToEnglish
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 325);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.grpChoseOne);
            this.Controls.Add(this.grpEnglish);
            this.Controls.Add(this.grpMetric);
            this.Controls.Add(this.btnConvert);
            this.Name = "frmEnglishToMetricToEnglish";
            this.Load += new System.EventHandler(this.EnglishToMetricToEnglishFrm_Load);
            this.grpMetric.ResumeLayout(false);
            this.grpMetric.PerformLayout();
            this.grpEnglish.ResumeLayout(false);
            this.grpEnglish.PerformLayout();
            this.grpChoseOne.ResumeLayout(false);
            this.grpChoseOne.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.TextBox txtCentimeters;
        private System.Windows.Forms.TextBox txtKilometers;
        private System.Windows.Forms.TextBox txtMeters;
        private System.Windows.Forms.RadioButton optMetricToEnglish;
        private System.Windows.Forms.RadioButton optEnglishToMetric;
        private System.Windows.Forms.GroupBox grpMetric;
        private System.Windows.Forms.CheckBox chkKilometers;
        private System.Windows.Forms.GroupBox grpEnglish;
        private System.Windows.Forms.TextBox txtInches;
        private System.Windows.Forms.TextBox txtFeet;
        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.TextBox txtYards;
        private System.Windows.Forms.GroupBox grpChoseOne;
        private System.Windows.Forms.CheckBox chkMiles;
        private System.Windows.Forms.CheckBox chkYards;
        private System.Windows.Forms.CheckBox chkInches;
        private System.Windows.Forms.CheckBox chkFeet;
        private System.Windows.Forms.CheckBox chkMeters;
        private System.Windows.Forms.CheckBox chkCentimeters;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}