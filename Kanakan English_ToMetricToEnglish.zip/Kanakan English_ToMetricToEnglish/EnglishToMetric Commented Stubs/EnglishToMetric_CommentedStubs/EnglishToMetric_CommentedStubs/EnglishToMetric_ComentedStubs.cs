﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishToMetric_CommentedStubs
{
    class EnglishToMetric_ComentedStubs//No code
    {
        private int miles;
        private int yards;
        private int feet;
        private double inches;
        private int kilometer;
        private int meters;
        private double centimeters;

        public EnglishToMetric()
        {
            //the attributes will be initialized here 
        }

        public EnglishToMetric(String theMiles, String theYards, String feet, String theInches)
        {
            //this will call 
            //convertEnglishToInches();
            //convertInchesToCentimeters();
            //convertCentimetersToMetersAndKilometers();

            //Will convert a english unit 
            //to the Metric unit  
        }

        public void convert()
        {
            //this will call 
            //convertEnglishToInches();

            //Will break down the number 
            //into the smallest unit of measurement
        }

        private void convertEnglishToInches()
        {
            //Will break down the number 
            //into the smallest unit of measurement

            //convertMilesToYards();
            //convertYardsToFeet();
            //convertFeetToInches();
        }

        private void convertMilesToYards()
        {
            //this will take the miles inputted
            //and convert it to Yards
        }
        private void convertYardsToFeet()
        {
            //this will take the Yards inputted
            //and convert it to feet
            //feet = yards * 3;
        }

        private void convertFeetToInches()
        {
            //this will take the feet inputted
            //and convert it to feet
            //inches = feet * 12;
        }
        private void convertInchesToCentimeters()
        {
            //centimeters = inches * 0.393701;
        }
        private void extractKilometerFromCentimeter()
        {
            //will take centimeters and turn it into
            //Kilometers

            //kilometer = (int)centimeters / 100000;
            //centimeters = centimeters % 100000;
        }

        public String getKilometers()
        {
            //return kilometer.ToString();
        }

        private void extractMetersFromCentimeter()
        {
            //will take centimeters and turn it into
            //Meters
            //meters = (int)centimeters / 100;
            //centimeters = centimeters % 100;
        }

        public String getMeters()
        {
            //This will get the Meters after
            //return meters.ToString();
        }

        private void convertCentimetersToMetersAndKilometers()
        {

            //extractMetersFromCentimeter();
            //extractKilometerFromCentimeter();
        }
    }
}
